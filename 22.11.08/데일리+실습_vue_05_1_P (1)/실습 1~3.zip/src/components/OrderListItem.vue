<template>
  <li>
    {{order.menu.title}}
    {{order.size.name}}
    {{totalPrice}}
  </li>
</template>

<script>
export default {
  name: 'OrderListItem',
  props: {
    order: Object,
  },
  computed: {
    totalPrice() {
      return this.order.menu.price + this.order.size.price
    },
  },
}
</script>

<style>
</style>