<template>
  <div>
    <h1>ImportantTodoPage</h1>
  </div>
</template>

<script>
export default {
  name: 'ImportantTodoPage'
}
</script>

<style>

</style>