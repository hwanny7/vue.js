# README

## PJT 09

### 코드 익힌 것

1. Object 구조 분해 할당 → Action에서 context 대신 {commit} 또는 {state}로 원하는 값만 호출 가능
2. d-flex, justify-content-center 사용
3. . class 이름:hover 을 사용해서 마우스가 위로 올라왔을 때 효과 부여 가능
4. (value, key) in Object 에서 key 값이 뒤에 온 다는 거
5. selection, opition으로 항목 선택 가능
6. classList.toggle(클래스이름)을 사용했을 때, 다른 router로 이동하고 돌아오면 상태 초기화
7. :class=””{ 클래스1:조건1 , 클래스2:조건2 }” 처럼 여러 조건 부여 가능
8. @click=” 메서드1, 메서드2 ” 처럼 쉼표(,)로 여러 메서드 실행 가능
9. Document.getElementById()로 router/index에서 태그로 접근 가능하다.

### 느낀점

1. 페어 덕분에 새로운 것을 많이 배울 수 있었으며 부족한 부분을 서로 메움
2. 따옴표(’) 또는 쉼표(,)를 누락하는 경우가 종종 있음. 예시, commit(’mutation이름’, payload)
3. 최종 프로젝트 진행할 때 페어와 유지보수를 편하게 하기 위해선 식별자를 통일하는게 중요한 것 같음